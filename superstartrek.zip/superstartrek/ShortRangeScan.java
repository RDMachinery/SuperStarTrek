package superstartrek;

public class ShortRangeScan {

    public ShortRangeScan() {
    }

    /**
     * Counts the objects in each of the 64 sectors of the quadrant containing
     * the given position. Results are indexed [sectorRow][sectorColumn].
     */
    public SRScanResult[][] scan(Galaxy galaxy, GalacticPosition quadrant) {
        SRScanResult[][] scanResult = new SRScanResult[8][8];
        for(int sectorColumn = 0; sectorColumn<8; sectorColumn++) {
            for(int sectorRow = 0; sectorRow<8; sectorRow++) {
                GalacticPosition gp = new GalacticPosition();
                gp.setPosition(quadrant.getQuadrantColumn(), quadrant.getQuadrantRow(),
                        sectorColumn, sectorRow);
                scanResult[sectorRow][sectorColumn] = new SRScanResult(gp);
            }
        }
        // one pass over the quadrant's objects, dropping each into its sector
        for (GameObject go : galaxy.getObjectsInQuadrant(quadrant.getQuadrantColumn(), quadrant.getQuadrantRow())) {
            GalacticPosition p = go.getPosition();
            scanResult[p.getSectorRow()][p.getSectorColumn()].add(go);
        }
        return scanResult;
    }

    public static class SRScanResult {
        GalacticPosition sector;
        public int numKlingons;
        public int numCommanders;
        public int numStarBases;
        public int numStars;
        public int numShips;

        public SRScanResult(GalacticPosition sector) {
            this.sector = sector;
        }

        public GalacticPosition getSector() {
            return sector;
        }

        void add(GameObject go) {
            if( go instanceof KlingonCommander )
                numCommanders++;
            else if( go instanceof Klingon )
                numKlingons++;
            else if( go instanceof StarBase )
                numStarBases++;
            else if( go instanceof  Star )
                numStars++;
            else if( go instanceof Enterprise )
                numShips++;
        }
    }
}
