package superstartrek;

public class Star extends GameObject {

    @Override
    public char getMapSymbol() { return '*'; }

    public String toString() { return "*";}
}
