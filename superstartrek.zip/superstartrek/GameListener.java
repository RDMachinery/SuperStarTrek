package superstartrek;

public interface GameListener {

    void handleEvent(GameEvent evt, GameEvent.EventName eventName);
}
