package superstartrek;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Holds every object in the galaxy, indexed two ways:
 * by parsec cell (for "what is at this exact position?") and by quadrant
 * (so scans and combat only look at the objects in one quadrant instead of
 * the whole galaxy).
 *
 * Objects keep the index up to date themselves through
 * {@link GameObject#setPosition(Galaxy, long, long)}.
 *
 * @author Mario
 */
public class Galaxy {

    private final HashMap<String, GameObject> cells = new HashMap<>();
    private final HashMap<Long, ArrayList<GameObject>> quadrants = new HashMap<>();

    public static String key(long parsecX, long parsecY) {
        return parsecX + ":" + parsecY;
    }

    private static long quadrantKey(long parsecX, long parsecY) {
        long qx = Math.floorDiv(parsecX, GalacticPosition.QUADRANT_WIDTH_PARSECS);
        long qy = Math.floorDiv(parsecY, GalacticPosition.QUADRANT_HEIGHT_PARSECS);
        return (qx << 32) ^ (qy & 0xffffffffL);
    }

    private static long quadrantKey(GameObject o) {
        GalacticPosition p = o.getPosition();
        return quadrantKey(p.getParsecX(), p.getParsecY());
    }

    /**
     * Adds an object at its current position.
     *
     * @throws IllegalStateException if a different object already occupies that parsec
     */
    public void add(GameObject o) {
        String k = o.getKey();
        GameObject existing = cells.get(k);
        if (existing == o)
            return;
        if (existing != null)
            throw new IllegalStateException("Parsec " + k + " is already occupied by " +
                    existing.getClass().getSimpleName());
        cells.put(k, o);
        quadrants.computeIfAbsent(quadrantKey(o), q -> new ArrayList<>()).add(o);
    }

    /**
     * Removes an object from its current position. Does nothing if the object
     * is not in the galaxy (it never removes a different object by mistake).
     */
    public void remove(GameObject o) {
        String k = o.getKey();
        if (cells.get(k) != o)
            return;
        cells.remove(k);
        long qk = quadrantKey(o);
        ArrayList<GameObject> list = quadrants.get(qk);
        if (list != null) {
            list.remove(o);
            if (list.isEmpty())
                quadrants.remove(qk);
        }
    }

    public GameObject get(long parsecX, long parsecY) {
        return cells.get(key(parsecX, parsecY));
    }

    public boolean isEmpty(long parsecX, long parsecY) {
        return !cells.containsKey(key(parsecX, parsecY));
    }

    /** A copy of the list of objects in a quadrant (safe to modify the galaxy while iterating). */
    public List<GameObject> getObjectsInQuadrant(int quadrantColumn, int quadrantRow) {
        long qk = quadrantKey((long) quadrantColumn * GalacticPosition.QUADRANT_WIDTH_PARSECS,
                (long) quadrantRow * GalacticPosition.QUADRANT_HEIGHT_PARSECS);
        ArrayList<GameObject> list = quadrants.get(qk);
        return list == null ? new ArrayList<>() : new ArrayList<>(list);
    }

    /** Counts the objects of a type (including subclasses) in the whole galaxy. */
    public int count(Class<? extends GameObject> type) {
        int n = 0;
        for (GameObject o : cells.values())
            if (type.isInstance(o))
                n++;
        return n;
    }

    public int size() {
        return cells.size();
    }

    public void clear() {
        cells.clear();
        quadrants.clear();
    }
}
