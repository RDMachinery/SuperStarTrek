package superstartrek;

import java.util.Random;

public class Klingon extends GameObject {

    private double energy;
    private boolean destroyed;

    public Klingon(double energy) {
        this.energy = energy;
    }

    public double getEnergy() {
        return energy;
    }

    protected void setEnergy(double energy) {
        this.energy = energy;
    }

    public boolean isDestroyed() {
        return destroyed;
    }

    /**
     * Applies a hit. When the Klingon's energy runs out it is destroyed and
     * listeners receive a KLINGON_DESTROYED event.
     */
    public void takeHit(double hit) {
        if (destroyed)
            return;
        energy -= hit;
        if (energy <= 0) {
            energy = 0;
            destroyed = true;
            notifyListeners(new GameEvent(this, GameEvent.EventName.KLINGON_DESTROYED));
        }
    }

    /** A photon torpedo destroys an ordinary battle cruiser outright. */
    public void takeTorpedo(Random rnd) {
        takeHit(energy + 1);
    }

    /** Firing drains the Klingon's energy. */
    public void afterFiring(Random rnd) {
        energy /= (3 + rnd.nextDouble());
    }

    public String getName() {
        return "Klingon";
    }

    @Override
    public char getMapSymbol() {
        return 'K';
    }

    public String toString() {
        return "+K+";
    }
}
