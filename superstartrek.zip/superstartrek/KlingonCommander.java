package superstartrek;

import java.util.Random;

/**
 * A Klingon Commander: carries more energy than an ordinary battle cruiser,
 * tires more slowly when firing, and can survive a photon torpedo hit.
 */
public class KlingonCommander extends Klingon {

    public KlingonCommander(double energy) {
        super(energy);
    }

    @Override
    public void takeTorpedo(Random rnd) {
        takeHit(250 + rnd.nextInt(250));
    }

    @Override
    public void afterFiring(Random rnd) {
        setEnergy(getEnergy() / (1.5 + rnd.nextDouble()));
    }

    @Override
    public String getName() {
        return "Klingon Commander";
    }

    @Override
    public char getMapSymbol() {
        return 'C';
    }

    @Override
    public String toString() {
        return "+C+";
    }
}
