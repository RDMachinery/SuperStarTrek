package superstartrek;

import java.util.LinkedList;
import java.util.List;

/**
 * Lays out a table of multi-line text cells as a bordered character grid.
 *
 * <pre>
 * +-----+-------+
 * |  1  |   2   |
 * +-----+-------+
 * | * x | +K+ x |
 * |  3  | <*> x |
 * +-----+-------+
 * </pre>
 *
 * Each column is as wide as its widest cell and each row as tall as its
 * tallest cell.
 */
public class TextBoxGrid {

    private LinkedList<LinkedList<TextBox>> model;
    private char[][] charBuffer;
    private TextBox.Alignment alignment = TextBox.Alignment.LEFT;
    private int padding = 1;

    public TextBoxGrid() {
        model = new LinkedList<>();
    }

    public void setAlignment(TextBox.Alignment alignment) {
        this.alignment = alignment;
    }

    /** Spaces between the cell border and its text, on the left and right. */
    public void setPadding(int padding) {
        this.padding = padding;
    }

    /**
     * Formats a table into a character buffer.
     *
     * @param table rows, each a list of cells, each cell a list of text lines
     * @return the rendered grid, indexed [line][column]
     */
    public char[][] format(List<? extends List<? extends List<String>>> table) {
        model.clear();

        int numColumns = 0;
        for (List<? extends List<String>> row : table) {
            LinkedList<TextBox> boxes = new LinkedList<>();
            for (List<String> cell : row) {
                TextBox tb = new TextBox();
                tb.setAlignment(alignment);
                tb.setInsets(0, 0, padding, padding);
                for (String line : cell)
                    tb.addText(line);
                boxes.add(tb);
            }
            numColumns = Math.max(numColumns, boxes.size());
            model.add(boxes);
        }

        int numRows = model.size();
        if (numRows == 0 || numColumns == 0) {
            charBuffer = new char[0][0];
            return charBuffer;
        }

        // column widths and row heights
        int[] columnWidth = new int[numColumns];
        int[] rowHeight = new int[numRows];
        int r = 0;
        for (LinkedList<TextBox> row : model) {
            rowHeight[r] = 1;
            int c = 0;
            for (TextBox tb : row) {
                columnWidth[c] = Math.max(columnWidth[c], tb.getWidth());
                rowHeight[r] = Math.max(rowHeight[r], tb.getHeight());
                c++;
            }
            r++;
        }
        for (int c = 0; c < numColumns; c++)
            columnWidth[c] = Math.max(columnWidth[c], 2 * padding + 1);

        // border positions
        int[] xBorder = new int[numColumns + 1];
        for (int c = 1; c <= numColumns; c++)
            xBorder[c] = xBorder[c - 1] + columnWidth[c - 1] + 1;
        int[] yBorder = new int[numRows + 1];
        for (r = 1; r <= numRows; r++)
            yBorder[r] = yBorder[r - 1] + rowHeight[r - 1] + 1;

        int width = xBorder[numColumns] + 1;
        int height = yBorder[numRows] + 1;
        charBuffer = new char[height][width];
        for (char[] line : charBuffer)
            java.util.Arrays.fill(line, ' ');

        // horizontal rules, vertical rules and the '+' where they cross
        for (int yb : yBorder)
            java.util.Arrays.fill(charBuffer[yb], '-');
        for (int y = 0; y < height; y++)
            for (int xb : xBorder)
                charBuffer[y][xb] = charBuffer[y][xb] == '-' ? '+' : '|';

        // cell contents
        r = 0;
        for (LinkedList<TextBox> row : model) {
            int c = 0;
            for (TextBox tb : row) {
                tb.setColumn(xBorder[c] + 1);
                tb.setRow(yBorder[r] + 1);
                int contentWidth = columnWidth[c] - tb.getInsetLeft() - tb.getInsetRight();
                List<String> lines = tb.getLines();
                for (int i = 0; i < lines.size(); i++) {
                    String s = formatString(lines.get(i), contentWidth, tb.getAlignment(), 0);
                    int y = tb.getRow() + tb.getInsetTop() + i;
                    int x = tb.getColumn() + tb.getInsetLeft();
                    for (int j = 0; j < s.length(); j++)
                        charBuffer[y][x + j] = s.charAt(j);
                }
                c++;
            }
            r++;
        }
        return charBuffer;
    }

    /** Joins a character buffer into printable lines. */
    public static String toString(char[][] buffer) {
        StringBuilder sb = new StringBuilder();
        for (char[] line : buffer)
            sb.append(line).append('\n');
        return sb.toString();
    }

    /**
     * Pads (or truncates) a string to exactly columnWidth characters using the
     * given alignment, with 'padding' extra spaces on each side.
     */
    static String formatString(String s, int columnWidth, TextBox.Alignment alignment, int padding) {
        StringBuilder buf = new StringBuilder();
        if (s.length() > columnWidth)
            s = s.substring(0, columnWidth);
        int free = columnWidth - s.length();

        appendSpaces(buf, padding);
        if( alignment == TextBox.Alignment.LEFT ) {
            buf.append(s);
            appendSpaces(buf, free);
        } else if( alignment == TextBox.Alignment.CENTER ) {
            int left = free / 2;
            appendSpaces(buf, left);
            buf.append(s);
            appendSpaces(buf, free - left);
        } else if( alignment == TextBox.Alignment.RIGHT ) {
            appendSpaces(buf, free);
            buf.append(s);
        }
        appendSpaces(buf, padding);
        return buf.toString();
    }

    private static void appendSpaces(StringBuilder buf, int numSpaces) {
        for(int i=0; i<numSpaces; i++)
            buf.append(' ');
    }
}
