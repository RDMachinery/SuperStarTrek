package superstartrek;

public class StarBase extends GameObject {

    private boolean destroyed;

    public boolean isDestroyed() {
        return destroyed;
    }

    /** Destroys the starbase and notifies listeners with STARBASE_DESTROYED. */
    public void destroy() {
        if (destroyed)
            return;
        destroyed = true;
        notifyListeners(new GameEvent(this, GameEvent.EventName.STARBASE_DESTROYED));
    }

    @Override
    public char getMapSymbol() {
        return 'B';
    }

    public String toString() {
        return ">!<";
    }
}
