package superstartrek;

import java.util.List;

public class LongRangeScan {

    public LongRangeScan() {}

    /**
     * Scans the 3 x 3 block of quadrants centred on the given position.
     * Quadrants outside the galaxy report -1 for every count.
     */
    public ScanResult[][] scan(Galaxy galaxy, GalacticPosition pos) {
        ScanResult[][] scanResult = new ScanResult[3][3];
        int quadCol = pos.getQuadrantColumn();
        int quadRow = pos.getQuadrantRow();
        for (int row = -1; row <= 1; row++) {
            for (int column = -1; column <= 1; column++) {
                GalacticPosition p = new GalacticPosition();
                p.setPosition(quadCol + column, quadRow + row, 0, 0);
                ScanResult sr = new ScanResult(p);
                sr.scan(galaxy);
                scanResult[row + 1][column + 1] = sr;
            }
        }
        return scanResult;
    }

    public static class ScanResult {
        public int numStars;
        public int numStarBases;
        public int numKlingons;
        private GalacticPosition pos;

        public ScanResult(GalacticPosition pos) {
            this.pos = pos;
        }

        public GalacticPosition getPosition() {
            return pos;
        }

        public boolean isOutsideGalaxy() {
            return pos.isOutsideGalaxy();
        }

        public void scan(Galaxy galaxy) {
            if( pos.isOutsideGalaxy() ) {
                numStars = -1;
                numStarBases = -1;
                numKlingons = -1;
                return;
            }
            List<GameObject> list = galaxy.getObjectsInQuadrant(pos.getQuadrantColumn(), pos.getQuadrantRow());
            for (GameObject go : list) {
                if (go instanceof Star)
                    numStars++;
                else if (go instanceof StarBase)
                    numStarBases++;
                else if (go instanceof Klingon)
                    numKlingons++;
            }
        }
        public String toString() {
            return " " + numKlingons + "" + numStarBases + "" + numStars + " ";
        }
    }
}
