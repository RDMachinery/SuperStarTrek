package superstartrek;

import java.util.ArrayList;

public abstract class GameObject {

    private GalacticPosition position;
    private ArrayList<GameListener> listeners;

    public GameObject() {

        position = new GalacticPosition();
        listeners = new ArrayList<>();
    }

    protected void notifyListeners(GameEvent evt) {
        for(int i=listeners.size()-1; i>=0; i--) {
            listeners.get(i).handleEvent(evt, evt.getEventName());
        }
    }

    public void addListener(GameListener l) {
        listeners.add(l);
    }

    public void removeListener(GameListener l) {
        listeners.remove(l);
    }

    public void setPosition(Galaxy galaxy, long parsecX, long parsecY) {
        galaxy.remove(this);
        position.setPosition(parsecX, parsecY);
        galaxy.add(this);
    }

    public void setPosition(Galaxy galaxy, int quadrantColumn, int quadrantRow, int sectorColumn, int sectorRow) {
        galaxy.remove(this);
        position.setPosition(quadrantColumn, quadrantRow, sectorColumn, sectorRow);
        galaxy.add(this);
    }

    public GalacticPosition getPosition() {
        GalacticPosition pos = new GalacticPosition();
        pos.setPosition(position.getParsecX(), position.getParsecY());
        return pos;
    }

    public String getKey() {
        return Galaxy.key(position.getParsecX(), position.getParsecY());
    }

    /** A single character used when drawing the parsec-level sector view. */
    public abstract char getMapSymbol();
}
