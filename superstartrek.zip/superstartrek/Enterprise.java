package superstartrek;

import java.util.EnumMap;

public class Enterprise extends GameObject {

    public static final int MAX_ENERGY = 3000;
    public static final int MAX_TORPEDOES = 10;

    private Condition condition;
    private int photonTorpedoes;
    private int totalEnergy;
    private int shields;
    private boolean destroyed;

    /** State of repair for each device: 0 = working, negative = damaged. */
    private final EnumMap<Device, Double> damage;

    private GalacticPosition previousPosition;

    public Enterprise() {
        condition = Condition.GREEN;
        photonTorpedoes = MAX_TORPEDOES;
        totalEnergy = MAX_ENERGY;
        shields = 0;
        previousPosition = new GalacticPosition();
        damage = new EnumMap<>(Device.class);
        for (Device d : Device.values())
            damage.put(d, 0.0);
    }
    public void setPosition(Galaxy galaxy, long parsecX, long parsecY) {
        previousPosition.setPosition(getPosition().getParsecX(), getPosition().getParsecY());
        super.setPosition(galaxy, parsecX, parsecY);
        if( previousPosition.getParsecX() == getPosition().getParsecX() &&
            previousPosition.getParsecY() == getPosition().getParsecY()) {
            // ship did not move
            return;
        }
        notifyListeners(new GameEvent(this, GameEvent.EventName.ENTERPRISE_MOVED));
    }
    public void setPosition(Galaxy galaxy,
                            int quadrantColumn, int quadrantRow,
                            int sectorColumn, int sectorRow) {
        previousPosition.setPosition(getPosition().getParsecX(), getPosition().getParsecY());
        super.setPosition(galaxy, quadrantColumn, quadrantRow, sectorColumn, sectorRow);
        if( previousPosition.getParsecX() == getPosition().getParsecX() &&
                previousPosition.getParsecY() == getPosition().getParsecY()) {
            // ship did not move
            return;
        }
        notifyListeners(new GameEvent(this, GameEvent.EventName.ENTERPRISE_MOVED));
    }
    public GalacticPosition getPreviousPosition() {
        return previousPosition;
    }

    //
    // Energy, shields and torpedoes
    //

    public int getEnergy() { return totalEnergy; }
    public int getShields() { return shields; }
    public int getTorpedoes() { return photonTorpedoes; }

    /**
     * Uses ship's energy. If there is not enough, shield control makes up the
     * difference from the shields.
     *
     * @return true if energy had to be drawn from the shields
     */
    public boolean useEnergy(int amount) {
        totalEnergy -= amount;
        if (totalEnergy >= 0)
            return false;
        shields += totalEnergy;
        totalEnergy = 0;
        if (shields < 0)
            shields = 0;
        return true;
    }

    /**
     * Moves energy between the ship and the shields.
     *
     * @return false if the requested level is not possible
     */
    public boolean setShields(int newShields) {
        int available = totalEnergy + shields;
        if (newShields < 0 || newShields > available)
            return false;
        totalEnergy = available - newShields;
        shields = newShields;
        return true;
    }

    /** Launching a torpedo uses one torpedo and 2 units of energy. */
    public void fireTorpedo() {
        photonTorpedoes--;
        useEnergy(2);
    }

    /**
     * Applies a Klingon hit to the shields. If the shields fail the ship is
     * destroyed and listeners receive ENTERPRISE_DESTROYED.
     */
    public void takeHit(int hit) {
        if (destroyed)
            return;
        shields -= hit;
        if (shields <= 0) {
            shields = 0;
            destroyed = true;
            notifyListeners(new GameEvent(this, GameEvent.EventName.ENTERPRISE_DESTROYED));
        }
    }

    public boolean isDestroyed() { return destroyed; }

    /** Docking at a starbase: full energy and torpedoes, shields dropped. */
    public void refit() {
        totalEnergy = MAX_ENERGY;
        photonTorpedoes = MAX_TORPEDOES;
        shields = 0;
    }

    //
    // Damage
    //

    public double getDamage(Device d) { return damage.get(d); }

    public boolean isDamaged(Device d) { return damage.get(d) < 0; }

    public void damageDevice(Device d, double amount) {
        damage.put(d, damage.get(d) - amount);
    }

    /**
     * Improves a device's state of repair.
     *
     * @return true if this repair brought a damaged device back into service
     */
    public boolean repairDevice(Device d, double amount) {
        double before = damage.get(d);
        double after = before + amount;
        // a device stays just short of repaired rather than flipping back too early
        if (before < 0 && after > -0.1 && after < 0)
            after = -0.1;
        damage.put(d, after);
        return before < 0 && after >= 0;
    }

    public void repairAll() {
        for (Device d : Device.values())
            if (damage.get(d) < 0)
                damage.put(d, 0.0);
    }

    public int damagedDeviceCount() {
        int n = 0;
        for (Device d : Device.values())
            if (isDamaged(d))
                n++;
        return n;
    }

    //
    // Condition
    //

    public Condition getCondition() { return condition; }
    public void setCondition(Condition condition) { this.condition = condition; }

    @Override
    public char getMapSymbol() {
        return 'E';
    }

    public String toString() {
        return "<*>";
    }

    public enum Condition {
        GREEN, YELLOW, RED, DOCKED
    }
}
