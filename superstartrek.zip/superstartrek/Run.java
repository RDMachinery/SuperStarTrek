package superstartrek;

import java.io.*;
import java.text.NumberFormat;
import java.util.*;

public class Run implements GameListener {

    /** Base energy of a Klingon battle cruiser; each one gets 50%-150% of this. */
    public static final double KLINGON_BASE_ENERGY = 200;

    public final static double EPSILON = 1e-12;

    private static final int QW = GalacticPosition.QUADRANT_WIDTH_PARSECS;
    private static final int QH = GalacticPosition.QUADRANT_HEIGHT_PARSECS;
    private static final int GALAXY_SECTORS = GalacticPosition.GALAXY_SIZE_SECTORS;

    private Galaxy galaxy;

    private Enterprise ship;
    private double stardate;
    private double startStardate;
    private double missionDays;

    private int initialKlingons;
    private int klingonsRemaining;
    private int starbasesRemaining;
    private boolean shipDestroyed;
    private boolean relievedOfCommand;

    /** Library computer memory: [row][column] -> {klingons, starbases, stars}, null = never scanned. */
    private int[][][] galacticRecord;

    private BufferedReader bufIn;
    private BufferedWriter bufOut;

    private static final String[] COMMANDS = {"nav","srs","lrs","pha","tor","she","dam","com","help","xxx","goto"};

    private static Random rnd;
    private long seed = 7276431L;

    private int performance; // 0..100%

    private final Map<String, String> helpText = buildHelpText();

    public Run() {
        galaxy = new Galaxy();
        bufIn = new BufferedReader(new InputStreamReader(System.in));
        bufOut = new BufferedWriter(new OutputStreamWriter(System.out));
    }

    private void reset() {
        ship = new Enterprise();
        galaxy.clear();
        rnd = new Random(seed);
        stardate = 3000;
        startStardate = stardate;
        performance = 100;
        shipDestroyed = false;
        relievedOfCommand = false;
        galacticRecord = new int[8][8][];
        placeStars();
        placeKlingons();
        placeStarBases();
        placeShip();

        missionDays = 25 + rnd.nextInt(10);
        if (initialKlingons >= missionDays)
            missionDays = initialKlingons + 1;

        ship.addListener(this);
    }

    //
    // Galaxy set-up
    //

    private void placeStars() {
        int sw = GalacticPosition.GALACTIC_WIDTH_PARSECS;
        int sh = GalacticPosition.GALACTIC_HEIGHT_PARSECS;
        // 64 x 64 sectors, about 5 stars per sector
        for(int i=0; i < 64 * 64 * 5; i++) {
            long[] p = randomFreeCell(0, 0, sw, sh);
            Star s = new Star();
            s.setPosition(galaxy, p[0], p[1]);
        }
    }

    /**
     * Each quadrant gets 0-3 Klingons, with the classic odds (about 19 in all).
     * Roughly one in seven is a Commander.
     */
    private void placeKlingons() {
        initialKlingons = 0;
        for (int qr = 0; qr < 8; qr++) {
            for (int qc = 0; qc < 8; qc++) {
                double r1 = rnd.nextDouble();
                int count = r1 > 0.98 ? 3 : r1 > 0.95 ? 2 : r1 > 0.80 ? 1 : 0;
                for (int i = 0; i < count; i++)
                    placeKlingon(qc, qr);
            }
        }
        if (initialKlingons == 0)
            placeKlingon(nextInt(0, 8), nextInt(0, 8));
        klingonsRemaining = initialKlingons;
    }

    private void placeKlingon(int qc, int qr) {
        double energy = KLINGON_BASE_ENERGY * (0.5 + rnd.nextDouble());
        Klingon k = rnd.nextDouble() < 0.15 ? new KlingonCommander(energy * 1.5) : new Klingon(energy);
        long[] p = randomFreeCellInQuadrant(qc, qr);
        k.setPosition(galaxy, p[0], p[1]);
        k.addListener(this);
        initialKlingons++;
    }

    private void placeStarBases() {
        starbasesRemaining = 0;
        for (int qr = 0; qr < 8; qr++)
            for (int qc = 0; qc < 8; qc++)
                if (rnd.nextDouble() > 0.96)
                    placeStarBase(qc, qr);
        if (starbasesRemaining == 0)
            placeStarBase(nextInt(0, 8), nextInt(0, 8));
    }

    private void placeStarBase(int qc, int qr) {
        StarBase s = new StarBase();
        long[] p = randomFreeCellInQuadrant(qc, qr);
        s.setPosition(galaxy, p[0], p[1]);
        s.addListener(this);
        starbasesRemaining++;
    }

    private void placeShip() {
        long[] p = randomFreeCell(0, 0, GalacticPosition.GALACTIC_WIDTH_PARSECS, GalacticPosition.GALACTIC_HEIGHT_PARSECS);
        ship.setPosition(galaxy, p[0], p[1]);
    }

    private long[] randomFreeCellInQuadrant(int qc, int qr) {
        return randomFreeCell(qc * QW, qr * QH, (qc + 1) * QW, (qr + 1) * QH);
    }

    private long[] randomFreeCell(int minX, int minY, int maxX, int maxY) {
        int x, y;
        do {
            x = nextInt(minX, maxX);
            y = nextInt(minY, maxY);
        } while (!galaxy.isEmpty(x, y));
        return new long[]{x, y};
    }

    //
    // Main loop
    //

    public void init() throws IOException {
        boolean playAgain = false;
        do{
            reset();
            commandLoop();
            playAgain = askPlayAgain();
        }while( playAgain );
    }

    private boolean askPlayAgain() throws IOException {
        boolean playAgain = false;
        out("Play again [Y:N] ? ");
        String s = getString();
        playAgain = s.equalsIgnoreCase("y");

        if( playAgain ) {
            out("Same setup [Y:N] ? ");
            s = getString();
            if( "n".equalsIgnoreCase(s)) {
                // This will give the player a new galaxy setup
                seed = ((int) (Math.random() * 100000));
            }
        }
        return playAgain;
    }

    private void commandLoop() throws IOException {
        printOrders();
        out("Your mission begins with your starship located in the\n");
        out("Galactic Quadrant, '" + ship.getPosition().getQuadrantName() + "'.\n");
        recordCurrentQuadrant();
        checkDocking();
        updateCondition();
        printPosition();
        shortRangeScan();
        out("\n");
        while( true ) {
            try {
                out("Enter command: ");
                String cmd = inputCommand();
                if( "nav".equals(cmd) ) {
                    inputCourse();
                } else if("xxx".equals(cmd)) {
                    resignCommission();
                    return;
                } else if("lrs".equals(cmd)) {
                    longRangeScan();
                } else if("srs".equals(cmd)) {
                    shortRangeScan();
                } else if("pha".equals(cmd)) {
                    firePhasers();
                } else if("tor".equals(cmd)) {
                    fireTorpedo();
                } else if("she".equals(cmd)) {
                    shieldControl();
                } else if("dam".equals(cmd)) {
                    damageControl();
                } else if("com".equals(cmd)) {
                    libraryComputer();
                } else if("help".equals(cmd)) {
                    inputHelp();
                } else if("goto".equals(cmd)) {
                    gotoPosition();
                } else {
                    out("Unknown command. Permitted commands are:\n");
                    printCommandList();
                    out("\n");
                }
            } catch(EOFException eof) {
                throw eof;
            } catch(IOException ioe) {
                out("Spock says,\"Most illogical Captain. "+
                        "The command computer seems to be malfunctioning.\": " + ioe.getMessage() + "\n");
            }
            if (checkGameOver())
                return;
        }
    }

    private String inputCommand() throws IOException {
        String cmd = getString().toLowerCase();
        for (String c : COMMANDS) {
            if (c.equals(cmd))
                return cmd;
        }
        return "";
    }

    private void printOrders() throws IOException {
        out("\n");
        out("                    *** SUPER STAR TREK ***\n\n");
        out("Your orders are as follows:\n");
        out("   Destroy the " + initialKlingons + " Klingon warships which have invaded the galaxy\n");
        out("   before they can attack Federation Headquarters on stardate " +
                fmt1(startStardate + missionDays) + ".\n");
        out("   This gives you " + (int) missionDays + " days. There " +
                (starbasesRemaining == 1 ? "is 1 starbase" : "are " + starbasesRemaining + " starbases") +
                " in the galaxy for resupplying your ship.\n\n");
        out("Type HELP for a list of commands.\n\n");
    }

    //
    // Game over checks
    //

    /** @return true when the game has ended (and the ending has been reported). */
    private boolean checkGameOver() throws IOException {
        if (shipDestroyed) {
            out("\nThe Enterprise has been destroyed. The Federation will be conquered.\n");
            printKlingonsLeft();
            return true;
        }
        if (relievedOfCommand) {
            printKlingonsLeft();
            return true;
        }
        if (klingonsRemaining <= 0) {
            out("\nCongratulations, Captain! The last Klingon battle cruiser menacing\n");
            out("the Federation has been destroyed.\n\n");
            double elapsed = Math.max(stardate - startStardate, 1.0);
            long efficiency = Math.round(1000 * Math.pow(initialKlingons / elapsed, 2));
            out("Mission time:        " + fmt1(stardate - startStardate) + " stardates\n");
            out("Efficiency:          " + formatInt(efficiency) + "\n");
            out("Performance rating:  " + performance + "%\n");
            out("Final score:         " + formatInt(efficiency * performance / 100) + "\n\n");
            return true;
        }
        if (stardate > startStardate + missionDays) {
            out("\nIt is stardate " + fmt1(stardate) + ". Your mission time has run out and the\n");
            out("Klingons have reached Federation Headquarters.\n");
            printKlingonsLeft();
            return true;
        }
        boolean stranded = ship.getEnergy() + ship.getShields() <= 10 ||
                (ship.getEnergy() <= 10 && ship.isDamaged(Device.SHIELD_CONTROL));
        if (stranded && !isDocked()) {
            out("\n** FATAL ERROR ** You've just stranded your ship in space.\n");
            out("You have insufficient maneuvering energy, and shield control is\n");
            out("unable to cross-circuit the shields to the engine room.\n");
            printKlingonsLeft();
            return true;
        }
        return false;
    }

    private void printKlingonsLeft() throws IOException {
        out("There " + (klingonsRemaining == 1 ? "was 1 Klingon battle cruiser" :
                "were " + klingonsRemaining + " Klingon battle cruisers") +
                " left at the end of your mission.\n\n");
    }

    private void resignCommission() throws IOException {
        out("Uhura says, \"An incoming message from Admiral Jameson, Captain.\"\n");
        out("\n\t'Your resignation has been accepted by Starfleet Command. I wish\n");
        out("\t you luck in your future endeavours.'\n\n");
        printKlingonsLeft();
    }

    //
    // Condition and docking
    //

    private void updateCondition() {
        if (isDocked())
            ship.setCondition(Enterprise.Condition.DOCKED);
        else if (!klingonsInQuadrant().isEmpty())
            ship.setCondition(Enterprise.Condition.RED);
        else if (ship.getEnergy() < Enterprise.MAX_ENERGY * 0.1)
            ship.setCondition(Enterprise.Condition.YELLOW);
        else
            ship.setCondition(Enterprise.Condition.GREEN);
    }

    private boolean isDocked() {
        return findAdjacentStarBase() != null;
    }

    /** A starbase in the ship's sector or any of the eight sectors around it. */
    private StarBase findAdjacentStarBase() {
        GalacticPosition sp = ship.getPosition();
        for (GameObject o : objectsInShipQuadrant()) {
            if (o instanceof StarBase && !((StarBase) o).isDestroyed()) {
                GalacticPosition bp = o.getPosition();
                if (Math.abs(bp.getSectorColumn() - sp.getSectorColumn()) <= 1 &&
                        Math.abs(bp.getSectorRow() - sp.getSectorRow()) <= 1)
                    return (StarBase) o;
            }
        }
        return null;
    }

    /** Called after every move: docking refuels and rearms the ship. */
    private void checkDocking() throws IOException {
        if (!isDocked())
            return;
        boolean hadShields = ship.getShields() > 0;
        ship.refit();
        out("Docked at starbase. Energy and photon torpedoes replenished.\n");
        if (hadShields)
            out("Shields dropped for docking purposes.\n");
    }

    //
    // Position display
    //

    private void printPosition() throws IOException {
        GalacticPosition shipPos = ship.getPosition();
        out("\n");
        out(shipPos.getQuadrantName() + "\n");
        int qc = shipPos.getQuadrantColumn() + 1;
        int qr = shipPos.getQuadrantRow() + 1;
        int sc = shipPos.getSectorColumn() + 1;
        int sr = shipPos.getSectorRow() + 1;

        if( ! shipPos.isOutsideGalaxy() ) {
            out("Quadrant: " + qc + ", " + qr +
                    " Sector: " + sc + ", " + sr);
            out("\n");
        } else {
            out("Quadrant: XX, XX Sector: XX, XX");
            out("\n");
            return;
        }
        GalacticPosition gpos = new GalacticPosition();
        gpos.setPosition(shipPos.getQuadrantColumn(), shipPos.getQuadrantRow(),
                shipPos.getSectorColumn(), shipPos.getSectorRow());

        StringBuilder border = new StringBuilder("+");
        for(int i=0; i<GalacticPosition.SECTOR_WIDTH_PARSECS; i++)
            border.append('-');
        border.append("+\n");
        out(border.toString());

        for(long parsecY=gpos.getParsecY(); parsecY<gpos.getParsecY() + GalacticPosition.SECTOR_HEIGHT_PARSECS; parsecY++) {
            StringBuilder line = new StringBuilder("|");
            for(long parsecX=gpos.getParsecX(); parsecX<gpos.getParsecX() + GalacticPosition.SECTOR_WIDTH_PARSECS; parsecX++) {
                GameObject go = galaxy.get(parsecX, parsecY);
                line.append(go == null ? ' ' : go.getMapSymbol());
            }
            line.append("|\n");
            out(line.toString());
        }

        out(border.toString());
        out("   E = Enterprise   K = Klingon   C = Klingon Commander   B = Starbase   * = Star\n");
        out("\n");
    }

    //
    // NAV
    //

    private void inputCourse()  throws IOException{
        double direction = 0;
        double warpFactor = 0;

        try {
            direction = inputDirection();
            warpFactor = inputWarpFactor();
        } catch(NumberFormatException nfe) {
            out("Uhura: \"Message received from Starfleet, Captain\"\n");
            out("\n\t'Supplying improper navigation course data can lead to your summary dismissal!'\n");
            decPerformance(10);
            return;
        }
        if (warpFactor == 0) {
            out("Course cancelled.\n");
            return;
        }
        if (ship.isDamaged(Device.WARP_ENGINES) && warpFactor > 0.2) {
            out("Warp engines are damaged. Maximum speed = warp 0.2\n");
            return;
        }
        moveShip(direction, warpFactor);
    }

    private double inputDirection() throws IOException, NumberFormatException {
        try {
            return inputCourseValue("Enter heading [1-9]: ");
        } catch(NumberFormatException e) {
            out("Sulu reports: \"That is not a valid heading, Sir.\"\n");
            throw e;
        }
    }

    /** Reads a course from 1 to 9 (9 is the same as 1). */
    private double inputCourseValue(String prompt) throws IOException, NumberFormatException {
        out(prompt);
        double course = Double.parseDouble(getString());
        if (!Course.isValid(course))
            throw new NumberFormatException("course out of range");
        return course >= 9 ? 1.0 : course;
    }

    private double inputWarpFactor() throws IOException, NumberFormatException {
        double warpFactor = -1;
        out("Enter Warp Factor: [0-8]: ");
        String wf = getString();
        try {
            warpFactor = Double.parseDouble(wf);
            if( warpFactor < 0 || warpFactor > 8 )
                throw new NumberFormatException();
        } catch(NumberFormatException e) {
            out("In the bowels of the engine room, Scotty yells: \"Captain, my engines cannae take that warp factor!\"\n");
            throw e;
        }
        return warpFactor;
    }

    /**
     * Moves the ship. Warp 1 crosses one quadrant (8 sectors). Inside the
     * starting quadrant the ship flies sector by sector and stops short of
     * Klingons, starbases and stars dead ahead; once it leaves the quadrant it
     * jumps straight to its destination. The ship cannot leave the galaxy.
     */
    private void moveShip(double direction, double warpFactor)  throws IOException {
        int sectorsToTravel = Math.max(1, (int) Math.round(warpFactor * 8));
        int energyNeeded = sectorsToTravel + 10;
        if (ship.getEnergy() < energyNeeded) {
            out("Engineering reports: \"Insufficient energy available for maneuvering at warp " +
                    warpFactor + "!\"\n");
            if (ship.getShields() > 0 && !ship.isDamaged(Device.SHIELD_CONTROL))
                out("Deflector control room acknowledges " + ship.getShields() +
                        " units of energy presently deployed to shields.\n");
            return;
        }

        out("Sulu: \"Heading " + direction + ", Warp Factor "+ warpFactor + ". Aye, Sir!\"\n");

        // Klingons in this quadrant open fire as the warp drive powers up
        klingonsAttack();
        if (shipDestroyed)
            return;

        repairDevicesInFlight(warpFactor);
        randomDamageEvent();

        GalacticPosition start = ship.getPosition();
        int startQuadrant = (int) start.getQuadrantNumber();
        double startX = start.getSectorUnitsX();
        double startY = start.getSectorUnitsY();
        int qc0 = start.getQuadrantColumn();
        int qr0 = start.getQuadrantRow();

        double[] v = Course.toVector(direction);
        double totalX = v[0] * warpFactor * 8;
        double totalY = v[1] * warpFactor * 8;

        // fly in tenth-of-a-sector steps while still inside the starting quadrant
        int steps = (int) Math.ceil(Math.max(Math.abs(totalX), Math.abs(totalY)) * 10);
        double lastX = startX, lastY = startY;
        int lastCellX = (int) Math.floor(startX), lastCellY = (int) Math.floor(startY);
        GameObject obstacle = null;
        boolean leftQuadrant = false;
        for (int i = 1; i <= steps; i++) {
            double t = (double) i / steps;
            double x = startX + totalX * t;
            double y = startY + totalY * t;
            int cellX = (int) Math.floor(x), cellY = (int) Math.floor(y);
            if (Math.floorDiv(cellX, 8) != qc0 || Math.floorDiv(cellY, 8) != qr0) {
                leftQuadrant = true;
                break;
            }
            GameObject at = galaxy.get(GalacticPosition.sectorUnitsToParsecX(x), GalacticPosition.sectorUnitsToParsecY(y));
            if (at instanceof Star) {
                obstacle = at;
                break;
            }
            if (cellX != lastCellX || cellY != lastCellY) {
                GameObject blocker = findTargetInSector(cellX, cellY);
                if (blocker != null) {
                    obstacle = blocker;
                    break;
                }
            }
            lastX = x; lastY = y;
            lastCellX = cellX; lastCellY = cellY;
        }

        double finalX, finalY;
        if (obstacle != null) {
            finalX = lastX;
            finalY = lastY;
            GalacticPosition op = obstacle.getPosition();
            out("Sulu: \"Emergency stop, Captain! " + describe(obstacle) + " dead ahead in sector " +
                    (op.getSectorColumn() + 1) + "," + (op.getSectorRow() + 1) + ".\"\n");
            out("Warp engines shut down at sector " + ((int) Math.floor(finalX) % 8 + 1) + "," +
                    ((int) Math.floor(finalY) % 8 + 1) + " due to bad navigation.\n");
        } else {
            finalX = startX + totalX;
            finalY = startY + totalY;
        }

        // the galactic perimeter
        boolean perimeter = false;
        double max = GALAXY_SECTORS - 1e-6;
        if (finalX < 0) { finalX = 0; perimeter = true; }
        if (finalY < 0) { finalY = 0; perimeter = true; }
        if (finalX > max) { finalX = max; perimeter = true; }
        if (finalY > max) { finalY = max; perimeter = true; }
        if (perimeter) {
            out("Uhura reports a message from Starfleet Command:\n");
            out("\t'Permission to cross the galactic perimeter is hereby *denied*.\n");
            out("\t Shut down your engines.'\n");
            out("Scotty: \"Warp engines shut down at the edge of the galaxy, Captain.\"\n");
            decPerformance(5);
        }

        long[] cell = freeCellNear(GalacticPosition.sectorUnitsToParsecX(finalX),
                GalacticPosition.sectorUnitsToParsecY(finalY));

        // the ENTERPRISE_MOVED handler prints the distance and the new position
        ship.setPosition(galaxy, cell[0], cell[1]);

        if (ship.useEnergy(energyNeeded))
            out("Shield control supplies energy to complete the maneuver.\n");
        stardate += warpFactor < 1 ? 0.1 * (int) (10 * warpFactor) : 1;

        if (ship.getPosition().getQuadrantNumber() != startQuadrant || leftQuadrant) {
            out("Now entering " + ship.getPosition().getQuadrantName() + " quadrant...\n");
            recordCurrentQuadrant();
        }
        checkDocking();
        updateCondition();
        if (ship.getCondition() == Enterprise.Condition.RED) {
            out("\n   COMBAT AREA      CONDITION RED\n");
            if (ship.getShields() <= 200)
                out("   SHIELDS DANGEROUSLY LOW\n");
            out("\n");
        }
    }

    /** After a move, each damaged device gets a little repair work done. */
    private void repairDevicesInFlight(double warpFactor) throws IOException {
        double amount = warpFactor >= 1 ? 1 : warpFactor;
        boolean header = false;
        for (Device d : Device.values()) {
            if (ship.isDamaged(d) && ship.repairDevice(d, amount)) {
                if (!header) {
                    out("Damage control report:\n");
                    header = true;
                }
                out("   " + d + " repair completed.\n");
            }
        }
    }

    /** One move in five, a random device is either damaged or improved. */
    private void randomDamageEvent() throws IOException {
        if (rnd.nextDouble() > 0.2)
            return;
        Device d = randomDevice();
        if (rnd.nextDouble() >= 0.6) {
            ship.repairDevice(d, rnd.nextDouble() * 3 + 1);
            out("Damage control report: " + d + " state of repair improved.\n");
        } else {
            ship.damageDevice(d, rnd.nextDouble() * 5 + 1);
            out("Damage control report: " + d + " damaged.\n");
        }
    }

    private Device randomDevice() {
        Device[] all = Device.values();
        return all[rnd.nextInt(all.length)];
    }

    /** The nearest free parsec cell (the ship's own cell counts as free). */
    private long[] freeCellNear(long px, long py) {
        for (int r = 0; r < 100; r++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dx = -r; dx <= r; dx++) {
                    if (Math.max(Math.abs(dx), Math.abs(dy)) != r)
                        continue;
                    long x = px + dx, y = py + dy;
                    if (x < 0 || y < 0 || x >= GalacticPosition.GALACTIC_WIDTH_PARSECS ||
                            y >= GalacticPosition.GALACTIC_HEIGHT_PARSECS)
                        continue;
                    GameObject o = galaxy.get(x, y);
                    if (o == null || o == ship)
                        return new long[]{x, y};
                }
            }
        }
        return new long[]{px, py};
    }

    private void gotoPosition() throws IOException {
        out("Enter position quad column, quad row, sec column, sec row (0-7): ");
        String s = getString();
        StringTokenizer st = new StringTokenizer(s,",");
        try {
            int qc = Integer.parseInt(st.nextToken().trim());
            int qr = Integer.parseInt(st.nextToken().trim());
            int sc = Integer.parseInt(st.nextToken().trim());
            int sr = Integer.parseInt(st.nextToken().trim());
            if (qc < 0 || qc > 7 || qr < 0 || qr > 7 || sc < 0 || sc > 7 || sr < 0 || sr > 7) {
                out("Position must be inside the galaxy (0-7 for each value).\n");
                return;
            }
            GalacticPosition target = new GalacticPosition();
            target.setPosition(qc, qr, sc, sr);
            long[] cell = freeCellNear(target.getParsecX(), target.getParsecY());
            ship.setPosition(galaxy, cell[0], cell[1]);
            recordCurrentQuadrant();
            checkDocking();
            updateCondition();
        } catch (NumberFormatException | NoSuchElementException e) {
            out("Expected four numbers separated by commas.\n");
        }
    }

    //
    // SRS
    //

    private void shortRangeScan() throws IOException {
        updateCondition();
        if (ship.isDamaged(Device.SHORT_RANGE_SENSORS)) {
            out("\n*** Short Range Sensors are out ***\n\n");
            return;
        }
        GalacticPosition pos = ship.getPosition();
        out("Short Range Scan for Quadrant " + (pos.getQuadrantColumn()+1) + "," +
                (pos.getQuadrantRow() + 1) + "  (" + pos.getQuadrantName() + ")\n");
        ShortRangeScan srs = new ShortRangeScan();
        ShortRangeScan.SRScanResult[][] result = srs.scan(galaxy, pos);

        List<List<List<String>>> rows = new ArrayList<>();
        List<List<String>> header = new ArrayList<>();
        header.add(lines(""));
        for (int column = 0; column < 8; column++)
            header.add(lines("" + (column + 1)));
        rows.add(header);

        for(int row=0; row<8; row++) {
            List<List<String>> r = new ArrayList<>();
            r.add(lines("" + (row + 1)));
            for(int column=0; column<8; column++)
                r.add(getCellList(result[row][column]));
            rows.add(r);
        }
        TextBoxGrid grid = new TextBoxGrid();
        grid.setAlignment(TextBox.Alignment.CENTER);
        out(TextBoxGrid.toString(grid.format(rows)));
        printStatus();
        recordCurrentQuadrant();
    }

    private List<String> getCellList(ShortRangeScan.SRScanResult sr) {
        List<String> cell = new ArrayList<>();
        if( sr.numKlingons > 0)
            cell.add("+K+ x " + sr.numKlingons);
        if( sr.numCommanders > 0)
            cell.add("+C+ x " + sr.numCommanders);
        if( sr.numStarBases > 0)
            cell.add(">!< x " + sr.numStarBases);
        if( sr.numStars > 0)
            cell.add("* x " + sr.numStars);
        if( sr.numShips > 0)
            cell.add("<*>");
        if (cell.isEmpty())
            cell.add(".");
        return cell;
    }

    private void printStatus() throws IOException {
        GalacticPosition pos = ship.getPosition();
        out(String.format("   Stardate            %s%n", fmt1(stardate)));
        out(String.format("   Condition           %s%n", conditionLabel()));
        out(String.format("   Quadrant            %d,%d%n", pos.getQuadrantColumn() + 1, pos.getQuadrantRow() + 1));
        out(String.format("   Sector              %d,%d%n", pos.getSectorColumn() + 1, pos.getSectorRow() + 1));
        out(String.format("   Photon torpedoes    %d%n", ship.getTorpedoes()));
        out(String.format("   Total energy        %d%n", ship.getEnergy() + ship.getShields()));
        out(String.format("   Shields             %d%n", ship.getShields()));
        out(String.format("   Klingons remaining  %d%n", klingonsRemaining));
        out(String.format("   Time remaining      %s stardates%n", fmt1(startStardate + missionDays - stardate)));
        if (ship.getCondition() == Enterprise.Condition.RED && ship.getShields() <= 200)
            out("   *** SHIELDS DANGEROUSLY LOW ***\n");
        out("\n");
    }

    private String conditionLabel() {
        switch (ship.getCondition()) {
            case RED: return "*RED*";
            case YELLOW: return "YELLOW";
            case DOCKED: return "DOCKED";
            default: return "GREEN";
        }
    }

    //
    // LRS
    //

    private void longRangeScan() throws IOException {
        if (ship.isDamaged(Device.LONG_RANGE_SENSORS)) {
            out("Long Range Sensors are inoperable.\n");
            return;
        }
        GalacticPosition pos = ship.getPosition();
        out("Long Range Scan for Quadrant " + (pos.getQuadrantColumn()+1) + "," +
                (pos.getQuadrantRow() + 1) + "   (Klingons Starbases Stars)\n");
        LongRangeScan scanner = new LongRangeScan();
        LongRangeScan.ScanResult[][] result = scanner.scan(galaxy, pos);

        List<List<List<String>>> rows = new ArrayList<>();
        for(int row=0; row<3; row++) {
            List<List<String>> r = new ArrayList<>();
            for(int column=0; column<3; column++) {
                LongRangeScan.ScanResult sr = result[row][column];
                if (sr.isOutsideGalaxy()) {
                    r.add(lines("#  #  ###"));
                } else {
                    r.add(lines(sr.numKlingons + "  " + sr.numStarBases + "  " + sr.numStars));
                    GalacticPosition q = sr.getPosition();
                    galacticRecord[q.getQuadrantRow()][q.getQuadrantColumn()] =
                            new int[]{sr.numKlingons, sr.numStarBases, sr.numStars};
                }
            }
            rows.add(r);
        }
        TextBoxGrid grid = new TextBoxGrid();
        grid.setAlignment(TextBox.Alignment.CENTER);
        out(TextBoxGrid.toString(grid.format(rows)));
    }

    /** Stores the current quadrant's contents in the library computer's record. */
    private void recordCurrentQuadrant() {
        GalacticPosition pos = ship.getPosition();
        int k = 0, b = 0, s = 0;
        for (GameObject o : objectsInShipQuadrant()) {
            if (o instanceof Klingon && !((Klingon) o).isDestroyed()) k++;
            else if (o instanceof StarBase) b++;
            else if (o instanceof Star) s++;
        }
        galacticRecord[pos.getQuadrantRow()][pos.getQuadrantColumn()] = new int[]{k, b, s};
    }

    //
    // PHA
    //

    private void firePhasers() throws IOException {
        List<Klingon> klingons = klingonsInQuadrant();
        if (klingons.isEmpty()) {
            out("Science Officer Spock reports: \"Sensors show no enemy ships in this quadrant.\"\n");
            return;
        }
        if (ship.isDamaged(Device.PHASER_CONTROL)) {
            out("Phasers inoperative.\n");
            return;
        }
        boolean computerDamaged = ship.isDamaged(Device.LIBRARY_COMPUTER);
        if (computerDamaged)
            out("Computer failure hampers accuracy.\n");

        out("Phasers locked on target; energy available = " + ship.getEnergy() + " units.\n");
        out("Number of units to fire: ");
        int units;
        try {
            units = Integer.parseInt(getString());
        } catch (NumberFormatException e) {
            out("Phaser control: \"Invalid energy setting, Captain.\"\n");
            return;
        }
        if (units <= 0)
            return;
        if (units > ship.getEnergy()) {
            out("Not enough energy, Captain. Energy available = " + ship.getEnergy() + " units.\n");
            return;
        }
        ship.useEnergy(units);

        double effective = computerDamaged ? units * rnd.nextDouble() : units;
        double perKlingon = effective / klingons.size();
        for (Klingon k : klingons) {
            double distance = Math.max(1.0, sectorDistance(ship, k));
            int hit = (int) ((perKlingon / distance) * (rnd.nextDouble() + 2));
            if (hit <= 0.15 * k.getEnergy()) {
                out("Sensors show no damage to " + k.getName() + " at " + sectorLabel(k) + ".\n");
                continue;
            }
            out(hit + " unit hit on " + k.getName() + " at sector " + sectorLabel(k) + ".\n");
            k.takeHit(hit);
            if (!k.isDestroyed())
                out("   (sensors show " + (int) Math.ceil(k.getEnergy()) + " units remaining)\n");
        }
        recordCurrentQuadrant();
        klingonsAttack();
        updateCondition();
    }

    //
    // TOR
    //

    private void fireTorpedo() throws IOException {
        if (ship.getTorpedoes() <= 0) {
            out("All photon torpedoes expended.\n");
            return;
        }
        if (ship.isDamaged(Device.PHOTON_TUBES)) {
            out("Photon tubes are not operational.\n");
            return;
        }
        double course;
        try {
            course = inputCourseValue("Photon torpedo course [1-9]: ");
        } catch (NumberFormatException e) {
            out("Ensign Chekov reports: \"Incorrect course data, sir!\"\n");
            return;
        }
        ship.fireTorpedo();
        out("Torpedo track:\n");

        GalacticPosition sp = ship.getPosition();
        int qc = sp.getQuadrantColumn(), qr = sp.getQuadrantRow();
        double[] v = Course.toUnitVector(course);
        double step = 0.05;
        double x = sp.getSectorUnitsX(), y = sp.getSectorUnitsY();
        int lastCellX = (int) Math.floor(x), lastCellY = (int) Math.floor(y);

        while (true) {
            x += v[0] * step;
            y += v[1] * step;
            int cellX = (int) Math.floor(x), cellY = (int) Math.floor(y);
            if (Math.floorDiv(cellX, 8) != qc || Math.floorDiv(cellY, 8) != qr) {
                out("Torpedo missed.\n");
                break;
            }
            // stars are point objects: only a direct hit absorbs the torpedo
            GameObject at = galaxy.get(GalacticPosition.sectorUnitsToParsecX(x), GalacticPosition.sectorUnitsToParsecY(y));
            if (at instanceof Star) {
                out("Star at sector " + sectorLabel(at) + " absorbed torpedo energy.\n");
                break;
            }
            if (cellX == lastCellX && cellY == lastCellY)
                continue;
            lastCellX = cellX;
            lastCellY = cellY;
            out("    " + (cellX % 8 + 1) + "," + (cellY % 8 + 1) + "\n");

            GameObject target = findTargetInSector(cellX, cellY);
            if (target instanceof Klingon) {
                Klingon k = (Klingon) target;
                out("Torpedo hits the " + k.getName() + " at sector " + sectorLabel(k) + "!\n");
                k.takeTorpedo(rnd);
                if (!k.isDestroyed())
                    out("   The " + k.getName() + "'s shields hold. (sensors show " +
                            (int) Math.ceil(k.getEnergy()) + " units remaining)\n");
                break;
            }
            if (target instanceof StarBase) {
                out("Torpedo hits the starbase at sector " + sectorLabel(target) + "!\n");
                ((StarBase) target).destroy();
                break;
            }
        }
        recordCurrentQuadrant();
        klingonsAttack();
        updateCondition();
    }

    /**
     * The first Klingon or starbase in a sector cell, given in galaxy-wide
     * sector coordinates (0-63).
     */
    private GameObject findTargetInSector(int cellX, int cellY) {
        for (GameObject o : galaxy.getObjectsInQuadrant(Math.floorDiv(cellX, 8), Math.floorDiv(cellY, 8))) {
            boolean target = (o instanceof Klingon && !((Klingon) o).isDestroyed()) ||
                    (o instanceof StarBase && !((StarBase) o).isDestroyed());
            if (!target)
                continue;
            GalacticPosition p = o.getPosition();
            if ((int) Math.floor(p.getSectorUnitsX()) == cellX && (int) Math.floor(p.getSectorUnitsY()) == cellY)
                return o;
        }
        return null;
    }

    //
    // Klingons open fire
    //

    private void klingonsAttack() throws IOException {
        if (klingonsRemaining <= 0)
            return;
        List<Klingon> klingons = klingonsInQuadrant();
        if (klingons.isEmpty())
            return;
        if (isDocked()) {
            out("Starbase shields protect the Enterprise.\n");
            return;
        }
        for (Klingon k : klingons) {
            if (k.getEnergy() <= 0)
                continue;
            double distance = Math.max(1.0, sectorDistance(ship, k));
            int hit = (int) ((k.getEnergy() / distance) * (2 + rnd.nextDouble()));
            k.afterFiring(rnd);
            out(hit + " unit hit on Enterprise from " + k.getName() + " at sector " + sectorLabel(k) + ".\n");
            ship.takeHit(hit);
            if (shipDestroyed)
                return;
            out("      <shields down to " + ship.getShields() + " units>\n");
            if (hit >= 20 && rnd.nextDouble() <= 0.6 && (double) hit / ship.getShields() > 0.02) {
                Device d = randomDevice();
                double damage = Math.min(5.0, (double) hit / ship.getShields() + 0.5 * rnd.nextDouble());
                ship.damageDevice(d, damage);
                out("Damage control reports: \"" + d + " damaged by the hit.\"\n");
            }
        }
    }

    //
    // SHE
    //

    private void shieldControl() throws IOException {
        if (ship.isDamaged(Device.SHIELD_CONTROL)) {
            out("Shield control inoperable.\n");
            return;
        }
        int available = ship.getEnergy() + ship.getShields();
        out("Energy available = " + available + ". Number of units to shields: ");
        int units;
        try {
            units = Integer.parseInt(getString());
        } catch (NumberFormatException e) {
            out("<Shields unchanged>\n");
            return;
        }
        if (units < 0 || units == ship.getShields()) {
            out("<Shields unchanged>\n");
            return;
        }
        if (!ship.setShields(units)) {
            out("Shield control reports: \"We don't have that much energy, Captain.\"\n");
            out("<Shields unchanged>\n");
            return;
        }
        out("Deflector control room report:\n");
        out("   \"Shields now at " + ship.getShields() + " units per your command.\"\n");
        updateCondition();
    }

    //
    // DAM
    //

    private void damageControl() throws IOException {
        if (ship.isDamaged(Device.DAMAGE_CONTROL))
            out("Damage control report not available.\n");
        else
            printDamageReport();

        if (isDocked() && ship.damagedDeviceCount() > 0) {
            double estimate = 0.1 * ship.damagedDeviceCount() + 0.5 * rnd.nextDouble();
            if (estimate >= 1)
                estimate = 0.9;
            out("\nTechnicians standing by to effect repairs to your ship.\n");
            out("Estimated time to repair: " + String.format("%.2f", estimate) + " stardates.\n");
            out("Will you authorize the repair order [Y:N] ? ");
            if ("y".equalsIgnoreCase(getString())) {
                ship.repairAll();
                stardate += estimate + 0.1;
                out("Repairs complete.\n");
                printDamageReport();
            }
        }
    }

    private void printDamageReport() throws IOException {
        out("\nDevice                 State of Repair\n");
        for (Device d : Device.values())
            out(String.format("%-22s %6.2f%s%n", d, ship.getDamage(d), ship.isDamaged(d) ? "  (damaged)" : ""));
        out("\n");
    }

    //
    // COM
    //

    private void libraryComputer() throws IOException {
        if (ship.isDamaged(Device.LIBRARY_COMPUTER)) {
            out("Computer disabled.\n");
            return;
        }
        out("Computer active and awaiting command (0-5): ");
        String s = getString();
        switch (s) {
            case "0": galacticRecordMap(); break;
            case "1": statusReport(); break;
            case "2": torpedoData(); break;
            case "3": starbaseNavData(); break;
            case "4": directionCalculator(); break;
            case "5": regionNameMap(); break;
            default:
                out("Functions available from library-computer:\n");
                out("   0 = Cumulative galactic record\n");
                out("   1 = Status report\n");
                out("   2 = Photon torpedo data\n");
                out("   3 = Starbase nav data\n");
                out("   4 = Direction/distance calculator\n");
                out("   5 = Galaxy 'region name' map\n");
        }
    }

    private void galacticRecordMap() throws IOException {
        GalacticPosition pos = ship.getPosition();
        out("Computer record of galaxy (Klingons Starbases Stars), Enterprise in quadrant " +
                (pos.getQuadrantColumn() + 1) + "," + (pos.getQuadrantRow() + 1) + "\n");
        List<List<List<String>>> rows = new ArrayList<>();
        List<List<String>> header = new ArrayList<>();
        header.add(lines(""));
        for (int c = 0; c < 8; c++)
            header.add(lines("" + (c + 1)));
        rows.add(header);
        for (int r = 0; r < 8; r++) {
            List<List<String>> row = new ArrayList<>();
            row.add(lines("" + (r + 1)));
            for (int c = 0; c < 8; c++) {
                int[] rec = galacticRecord[r][c];
                List<String> cell = lines(rec == null ? "***" : rec[0] + " " + rec[1] + " " + rec[2]);
                if (r == pos.getQuadrantRow() && c == pos.getQuadrantColumn())
                    cell.add("<*>");
                row.add(cell);
            }
            rows.add(row);
        }
        TextBoxGrid grid = new TextBoxGrid();
        grid.setAlignment(TextBox.Alignment.CENTER);
        out(TextBoxGrid.toString(grid.format(rows)));
    }

    private void statusReport() throws IOException {
        out("   Status report:\n");
        out("Klingon" + (klingonsRemaining == 1 ? "" : "s") + " left: " + klingonsRemaining + "\n");
        out("Mission must be completed in " + fmt1(startStardate + missionDays - stardate) + " stardates.\n");
        if (starbasesRemaining > 0)
            out("The Federation is maintaining " + starbasesRemaining + " starbase" +
                    (starbasesRemaining == 1 ? "" : "s") + " in the galaxy.\n");
        else
            out("Your stupidity has left you on your own in the galaxy -- you have no starbases left!\n");
        if (!ship.isDamaged(Device.DAMAGE_CONTROL))
            printDamageReport();
    }

    private void torpedoData() throws IOException {
        List<Klingon> klingons = klingonsInQuadrant();
        if (klingons.isEmpty()) {
            out("Science Officer Spock reports: \"Sensors show no enemy ships in this quadrant.\"\n");
            return;
        }
        out("From Enterprise to Klingon battle cruiser" + (klingons.size() > 1 ? "s" : "") + ":\n");
        for (Klingon k : klingons)
            printDirectionTo(k.getName() + " at sector " + sectorLabel(k), k);
    }

    private void starbaseNavData() throws IOException {
        boolean found = false;
        for (GameObject o : objectsInShipQuadrant()) {
            if (o instanceof StarBase) {
                if (!found)
                    out("From Enterprise to starbase:\n");
                found = true;
                printDirectionTo("Starbase at sector " + sectorLabel(o), o);
            }
        }
        if (!found)
            out("Mr. Spock reports: \"Sensors show no starbases in this quadrant.\"\n");
    }

    private void printDirectionTo(String label, GameObject target) throws IOException {
        GalacticPosition sp = ship.getPosition();
        GalacticPosition tp = target.getPosition();
        double dx = tp.getSectorUnitsX() - sp.getSectorUnitsX();
        double dy = tp.getSectorUnitsY() - sp.getSectorUnitsY();
        out(String.format("   %-36s direction %.2f, distance %.2f%n", label + ":",
                Course.fromDelta(dx, dy), Course.distance(dx, dy)));
    }

    private void directionCalculator() throws IOException {
        out("Direction/distance calculator:\n");
        GalacticPosition sp = ship.getPosition();
        out("You are at quadrant " + (sp.getQuadrantColumn() + 1) + "," + (sp.getQuadrantRow() + 1) +
                ", sector " + (sp.getSectorColumn() + 1) + "," + (sp.getSectorRow() + 1) + ".\n");
        out("Target quadrant column,row,sector column,row (1-8): ");
        StringTokenizer st = new StringTokenizer(getString(), ",");
        int qc, qr, sc, sr;
        try {
            qc = Integer.parseInt(st.nextToken().trim());
            qr = Integer.parseInt(st.nextToken().trim());
            sc = Integer.parseInt(st.nextToken().trim());
            sr = Integer.parseInt(st.nextToken().trim());
        } catch (NumberFormatException | NoSuchElementException e) {
            out("Expected four numbers separated by commas.\n");
            return;
        }
        if (qc < 1 || qc > 8 || qr < 1 || qr > 8 || sc < 1 || sc > 8 || sr < 1 || sr > 8) {
            out("Each value must be between 1 and 8.\n");
            return;
        }
        // aim for the centre of the target sector
        double tx = (qc - 1) * 8 + (sc - 1) + 0.5;
        double ty = (qr - 1) * 8 + (sr - 1) + 0.5;
        double dx = tx - sp.getSectorUnitsX();
        double dy = ty - sp.getSectorUnitsY();
        if (Math.abs(dx) < 0.5 && Math.abs(dy) < 0.5) {
            out("You are already in that sector.\n");
            return;
        }
        out(String.format("Direction = %.2f%nDistance  = %.2f sectors%nWarp factor needed = %.3f%n",
                Course.fromDelta(dx, dy), Course.distance(dx, dy), Course.warpFactorFor(dx, dy)));
    }

    private void regionNameMap() throws IOException {
        out("                        The Galaxy\n");
        List<List<List<String>>> rows = new ArrayList<>();
        List<List<String>> header = new ArrayList<>();
        header.add(lines(""));
        header.add(lines("Quadrants 1-4"));
        header.add(lines("Quadrants 5-8"));
        rows.add(header);
        for (int r = 0; r < 8; r++) {
            List<List<String>> row = new ArrayList<>();
            row.add(lines("" + (r + 1)));
            row.add(lines(GalacticPosition.GALACTIC_REGION_NAMES[r * 2]));
            row.add(lines(GalacticPosition.GALACTIC_REGION_NAMES[r * 2 + 1]));
            rows.add(row);
        }
        TextBoxGrid grid = new TextBoxGrid();
        grid.setAlignment(TextBox.Alignment.CENTER);
        grid.setPadding(4);
        out(TextBoxGrid.toString(grid.format(rows)));
    }

    //
    // HELP
    //

    private void printCommandList()  throws IOException{
        out("\tNAV  - Warp engine control.\n");
        out("\tSRS  - Short Range Scan.\n");
        out("\tLRS  - Long Range Scan.\n");
        out("\tPHA  - Fire phasers.\n");
        out("\tTOR  - Fire photon torpedoes.\n");
        out("\tSHE  - Shield control.\n");
        out("\tDAM  - Damage control report.\n");
        out("\tCOM  - Call on library-computer.\n");
        out("\tXXX  - Resign your commission.\n");
        out("\tHELP - Print the help information for a given command.\n");
    }

    private void inputHelp() throws IOException {
        out("Enter the command you need help with: ");
        String cmd = getString().toLowerCase();
        if( cmd.equals("")) {
            printCommandList();
            return;
        }
        String text = helpText.get(cmd);
        if (text == null) {
            out("No help available for '" + cmd + "'. Permitted commands are:\n");
            printCommandList();
            return;
        }
        out(text);
    }

    private static Map<String, String> buildHelpText() {
        Map<String, String> h = new HashMap<>();
        h.put("nav",
                "NAV - Warp engine control.\n" +
                "  Course is a number from 1 to 9 on this compass (9 is the same as 1):\n\n" +
                "         4  3  2\n" +
                "          \\ | /\n" +
                "       5 --<*>-- 1\n" +
                "          / | \\\n" +
                "         6  7  8\n\n" +
                "  Fractions are allowed: 2.5 is half-way between 2 and 3.\n" +
                "  Warp factor 1 moves you one quadrant (8 sectors); warp 0.125 moves one sector.\n" +
                "  A move costs 10 energy plus 1 per sector and takes 1 stardate (less below warp 1).\n" +
                "  Klingons in your quadrant fire as you leave. Damaged engines limit you to warp 0.2.\n");
        h.put("srs",
                "SRS - Short Range Scan.\n" +
                "  Shows the 8 x 8 sectors of your quadrant and your ship's status.\n" +
                "  <*> = Enterprise, +K+ = Klingon, +C+ = Klingon Commander, >!< = Starbase, * = Star.\n");
        h.put("lrs",
                "LRS - Long Range Scan.\n" +
                "  Shows the quadrants around you as three numbers: Klingons, Starbases, Stars.\n" +
                "  '#  #  ###' means the quadrant is outside the galaxy. Results are kept in\n" +
                "  the library computer's galactic record (COM 0).\n");
        h.put("pha",
                "PHA - Fire phasers.\n" +
                "  The energy you fire is divided between the Klingons in the quadrant.\n" +
                "  Hits weaken with distance. Phaser energy comes from the ship, not the shields.\n" +
                "  A damaged library computer makes phaser fire less accurate.\n");
        h.put("tor",
                "TOR - Fire photon torpedoes.\n" +
                "  Enter a course as for NAV. A torpedo destroys the first Klingon or starbase\n" +
                "  whose sector it enters (Commanders may survive one). A direct hit on a star\n" +
                "  absorbs it. COM 2 calculates the course to each Klingon.\n");
        h.put("she",
                "SHE - Shield control.\n" +
                "  Moves energy between the ship and the shields. Klingon hits drain the shields;\n" +
                "  if a hit takes them to zero, the Enterprise is destroyed.\n");
        h.put("dam",
                "DAM - Damage control report.\n" +
                "  Shows the state of repair of each device (negative = damaged). Devices repair\n" +
                "  slowly as you travel. When docked, the starbase can repair everything at once.\n");
        h.put("com",
                "COM - Library-computer. Options:\n" +
                "   0 = Cumulative galactic record of every quadrant you have scanned\n" +
                "   1 = Status report\n" +
                "   2 = Photon torpedo data (course and distance to each Klingon)\n" +
                "   3 = Starbase nav data\n" +
                "   4 = Direction/distance calculator (includes the warp factor needed)\n" +
                "   5 = Galaxy 'region name' map\n");
        h.put("xxx", "XXX - Resign your commission and end the game.\n");
        h.put("help", "HELP - Show help for a command.\n");
        return h;
    }

    //
    // Helpers
    //

    private List<GameObject> objectsInShipQuadrant() {
        GalacticPosition p = ship.getPosition();
        return galaxy.getObjectsInQuadrant(p.getQuadrantColumn(), p.getQuadrantRow());
    }

    private List<Klingon> klingonsInQuadrant() {
        List<Klingon> list = new ArrayList<>();
        for (GameObject o : objectsInShipQuadrant())
            if (o instanceof Klingon && !((Klingon) o).isDestroyed())
                list.add((Klingon) o);
        return list;
    }

    /** Distance between two objects in sector units. */
    private static double sectorDistance(GameObject a, GameObject b) {
        GalacticPosition pa = a.getPosition(), pb = b.getPosition();
        return Math.hypot(pa.getSectorUnitsX() - pb.getSectorUnitsX(),
                pa.getSectorUnitsY() - pb.getSectorUnitsY());
    }

    private static String sectorLabel(GameObject o) {
        GalacticPosition p = o.getPosition();
        return (p.getSectorColumn() + 1) + "," + (p.getSectorRow() + 1);
    }

    private static String describe(GameObject o) {
        if (o instanceof Klingon) return "A " + ((Klingon) o).getName();
        if (o instanceof StarBase) return "A starbase";
        if (o instanceof Star) return "A star";
        return "An object";
    }

    private static List<String> lines(String... text) {
        return new ArrayList<>(Arrays.asList(text));
    }

    private static String fmt1(double d) {
        return String.format("%.1f", d);
    }

    private void decPerformance(int amount) throws IOException{
        out("\nYour action has negatively affected your performance rating by " + amount + "%.\n");
        performance -= amount;
        if( performance < 0)
            performance = 0;
    }

    /** Reads a trimmed line; end of input ends the game. */
    private String getString() throws IOException {
        String line =  bufIn.readLine();
        if (line == null)
            throw new EOFException("End of input");
        return line.trim();
    }

    private void out(String s)  throws IOException{
        bufOut.write(s);
        bufOut.flush();
    }

    private String formatInt(long num) {
        return NumberFormat.getInstance().format(num);
    }

    /**
     *
     * Generate a random integer from rangeMin to rangeMax-1.
     *
     * @param rangeMin start range
     * @param rangeMax end range
     * @return the random number
     */
    public static int nextInt(int rangeMin, int rangeMax) {
        return (int) (rangeMin + (rangeMax - rangeMin) * rnd.nextDouble());
    }

    //
    // Listener interface implementation
    //
    public void handleEvent(GameEvent evt, GameEvent.EventName eventName)  {

        try {
            if (eventName == GameEvent.EventName.ENTERPRISE_MOVED) {
                GalacticPosition oldPos = ship.getPreviousPosition();

                if (ship.getPosition().isOutsideGalaxy()) {
                    out("Spock says, \"Captain, according to the navigation computer the ship is now outside the galaxy.\n");
                    out("             Logically, the correct action would be to reverse course.\"\n");
                    decPerformance(10);
                    return;
                }

                int distanceTravelled = (int) oldPos.distance(ship.getPosition());
                out("Distance travelled: " + formatInt(distanceTravelled) + " parsecs.\n");
                printPosition();

            } else if (eventName == GameEvent.EventName.ENTERPRISE_DESTROYED) {
                shipDestroyed = true;

            } else if (eventName == GameEvent.EventName.KLINGON_DESTROYED) {
                Klingon k = (Klingon) evt.getSource();
                galaxy.remove(k);
                klingonsRemaining--;
                out("*** " + k.getName() + " destroyed ***\n");
                if (klingonsRemaining > 0)
                    out("    " + klingonsRemaining + " Klingon" + (klingonsRemaining == 1 ? "" : "s") +
                            " remaining.\n");

            } else if (eventName == GameEvent.EventName.STARBASE_DESTROYED) {
                galaxy.remove(evt.getSource());
                starbasesRemaining--;
                out("*** Starbase destroyed ***\n");
                if (starbasesRemaining > 0) {
                    out("Starfleet Command is reviewing your record to consider court martial!\n");
                } else {
                    out("That does it, Captain! You are hereby relieved of command\n");
                    out("and sentenced to 99 stardates of hard labour on Cygnus 12!\n");
                    relievedOfCommand = true;
                }
                decPerformance(25);
            }
        }catch(IOException ioe) {
            System.out.println(ioe.getMessage());
            ioe.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Run r = new Run();
        try {
            r.init();
        }catch(EOFException eof) {
            System.out.println("\nInput closed. Goodbye, Captain.");
        }catch(IOException ioe) {
            System.out.println("An I/O error occurred. There appears to be a problem with reading. or writing to your terminal's "+
                    "standard input and standard output.\n");
            System.out.println("IOException returned message: " + ioe.getMessage());
            ioe.printStackTrace();
        }
    }
}
