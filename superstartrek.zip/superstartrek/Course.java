package superstartrek;

/**
 * Course (heading) maths, using the classic Star Trek compass:
 *
 * <pre>
 *      4  3  2
 *       \ | /
 *    5 --<*>-- 1
 *       / | \
 *      6  7  8
 * </pre>
 *
 * Whole numbers are the eight compass directions; fractional courses
 * interpolate between neighbouring directions (2.5 is half-way between
 * 2 and 3). Course 9 is the same as course 1.
 *
 * Vectors are in sector units (one quadrant = 8 x 8 sector units) with
 * y increasing downwards, matching the galaxy's parsec coordinates.
 * For every course, the dominant component of the vector is exactly 1,
 * so a ship moving N steps covers N sectors along its main axis.
 *
 * @author Mario
 */
public final class Course {

    /** Index 0 = course 1 ... index 7 = course 8, index 8 = course 9 (= course 1). */
    private static final double[][] DIRECTIONS = {
            { 1,  0}, { 1, -1}, { 0, -1}, {-1, -1},
            {-1,  0}, {-1,  1}, { 0,  1}, { 1,  1},
            { 1,  0}};

    private Course() {}

    public static boolean isValid(double course) {
        return course >= 1.0 && course <= 9.0;
    }

    /**
     * The displacement of one step along a course, in sector units.
     */
    public static double[] toVector(double course) {
        if (!isValid(course))
            throw new IllegalArgumentException("Course must be between 1 and 9: " + course);
        if (course >= 9.0)
            course = 1.0;
        int i = (int) course;
        double f = course - i;
        double[] a = DIRECTIONS[i - 1];
        double[] b = DIRECTIONS[i];
        return new double[]{a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f};
    }

    /** The course vector scaled to length 1. */
    public static double[] toUnitVector(double course) {
        double[] v = toVector(course);
        double len = Math.hypot(v[0], v[1]);
        return new double[]{v[0] / len, v[1] / len};
    }

    /**
     * The course that points along the given displacement (in sector units).
     * Returns a value in the range [1, 9).
     */
    public static double fromDelta(double dx, double dy) {
        if (dx == 0 && dy == 0)
            return 1.0;
        double target = angle(dx, dy);
        // angle(toVector(c)) increases monotonically from 0 (c=1) to 2*PI (c->9)
        double lo = 1.0, hi = 9.0;
        for (int i = 0; i < 60; i++) {
            double mid = (lo + hi) / 2;
            double[] v = toVector(mid);
            if (angle(v[0], v[1]) < target)
                lo = mid;
            else
                hi = mid;
        }
        double c = (lo + hi) / 2;
        return c >= 9.0 ? 1.0 : c;
    }

    /** Euclidean distance in sector units. */
    public static double distance(double dx, double dy) {
        return Math.hypot(dx, dy);
    }

    /**
     * The warp factor needed to cover a displacement exactly when flying the
     * course returned by {@link #fromDelta(double, double)}.
     */
    public static double warpFactorFor(double dx, double dy) {
        return Math.max(Math.abs(dx), Math.abs(dy)) / 8.0;
    }

    /** Angle in [0, 2*PI), measured anticlockwise from east, with y pointing down. */
    private static double angle(double dx, double dy) {
        double a = Math.atan2(-dy, dx);
        if (a < 0)
            a += 2 * Math.PI;
        return a;
    }
}
