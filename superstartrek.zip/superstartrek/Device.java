package superstartrek;

/**
 * The ship systems that can be damaged in combat or by random events.
 * A device with a negative state of repair is inoperable.
 */
public enum Device {
    WARP_ENGINES("Warp Engines"),
    SHORT_RANGE_SENSORS("Short Range Sensors"),
    LONG_RANGE_SENSORS("Long Range Sensors"),
    PHASER_CONTROL("Phaser Control"),
    PHOTON_TUBES("Photon Tubes"),
    DAMAGE_CONTROL("Damage Control"),
    SHIELD_CONTROL("Shield Control"),
    LIBRARY_COMPUTER("Library-Computer");

    private final String displayName;

    Device(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String toString() {
        return displayName;
    }
}
